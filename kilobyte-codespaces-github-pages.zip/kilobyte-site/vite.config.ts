import { defineConfig, loadEnv } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, ".", "");

  if (env.SITE_BASE) {
    return {
      plugins: [react()],
      base: env.SITE_BASE,
    };
  }

  const repo = env.GITHUB_REPOSITORY
    ? env.GITHUB_REPOSITORY.split("/")[1]
    : "";

  const inActions = env.GITHUB_ACTIONS === "true";

  const isUserPagesRepo =
    repo.length >= 10 &&
    repo.slice(repo.length - 10) === ".github.io";

  const base =
    inActions && repo && !isUserPagesRepo
      ? "/" + repo + "/"
      : "/";

  return {
    plugins: [react()],
    base,
  };
});

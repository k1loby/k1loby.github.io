#!/usr/bin/env bash
set -euo pipefail

ALT_USER="${1:-}"

if [ -z "$ALT_USER" ]; then
  echo "Usage: bash codespaces-publish.sh YOUR_ALT_USERNAME"
  exit 1
fi

REPO_ROOT="$(git rev-parse --show-toplevel)"
PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
TMP_OUT="/tmp/kilobyte-pages-output"

echo "[1/5] installing build dependencies in Codespaces"
cd "$PROJECT_DIR"
npm install --no-audit --no-fund

echo "[2/5] building for https://${ALT_USER}.github.io/"
SITE_BASE=/ npm run build

rm -rf "$TMP_OUT"
mkdir -p "$TMP_OUT"
cp -a dist/. "$TMP_OUT/"
cp -f "$TMP_OUT/index.html" "$TMP_OUT/404.html"
touch "$TMP_OUT/.nojekyll"

echo "[3/5] replacing repository with compiled website only"
cd "$REPO_ROOT"
git checkout --orphan kilobyte-pages-clean
find . -mindepth 1 -maxdepth 1 ! -name ".git" -exec rm -rf {} +
cp -a "$TMP_OUT"/. .

echo "[4/5] creating clean deployment commit"
git config user.name "kilobyte"
git config user.email "kilobyte@users.noreply.github.com"
git add -A
git commit -m "deploy site"
git branch -M main

echo "[5/5] pushing clean Pages branch"
git push --force origin main

echo
echo "DONE"
echo "Only compiled site files remain in the public branch."
echo "GitHub -> Settings -> Pages -> Deploy from a branch -> main -> /(root)"
echo "Site: https://${ALT_USER}.github.io/"

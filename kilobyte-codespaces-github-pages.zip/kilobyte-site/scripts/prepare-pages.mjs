import {
  copyFileSync,
  existsSync,
  writeFileSync,
} from "node:fs";
import { resolve } from "node:path";

const dist = resolve("dist");
const index = resolve(dist, "index.html");

if (!existsSync(index)) {
  throw new Error("dist/index.html was not generated");
}

copyFileSync(
  index,
  resolve(dist, "404.html"),
);

writeFileSync(
  resolve(dist, ".nojekyll"),
  "",
);

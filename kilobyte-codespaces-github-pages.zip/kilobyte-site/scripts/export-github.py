from pathlib import Path
import zipfile

root = Path(__file__).resolve().parents[1]
output = Path("/sdcard/Download/kilobyte-github-pages-source.zip")

excluded_dirs = {
    ".git",
    "node_modules",
    "dist",
    ".vite",
    "whiteboard-data",
}

excluded_names = {
    ".DS_Store",
}

if output.exists():
    output.unlink()

with zipfile.ZipFile(
    output,
    "w",
    zipfile.ZIP_DEFLATED,
) as archive:
    for path in root.rglob("*"):
        relative = path.relative_to(root)

        if any(
            part in excluded_dirs
            for part in relative.parts
        ):
            continue

        if path.name in excluded_names:
            continue

        if path.suffix.lower() == ".zip":
            continue

        if path.is_file():
            archive.write(
                path,
                Path("personal-website") / relative,
            )

print(output)

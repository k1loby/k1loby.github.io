from pathlib import Path
import zipfile

root = Path(__file__).resolve().parents[1]
dist = root / "dist"
output = Path("/sdcard/Download/kilobyte-pages.zip")

if not (dist / "index.html").exists():
    raise SystemExit("dist/index.html is missing. Run publish-pages.sh first.")

if output.exists():
    output.unlink()

with zipfile.ZipFile(
    output,
    "w",
    compression=zipfile.ZIP_DEFLATED,
    compresslevel=9,
) as archive:
    for path in dist.rglob("*"):
        if path.is_file():
            archive.write(
                path,
                path.relative_to(dist),
            )

print(output)

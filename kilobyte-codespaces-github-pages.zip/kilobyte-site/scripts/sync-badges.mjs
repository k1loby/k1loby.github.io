import fs from "node:fs";
import path from "node:path";

const sharedDir =
  process.env.DOTUI_BADGES_DIR ||
  "/sdcard/Download/dotui-badges";

const projectDir = process.cwd();

const publicDir = path.join(
  projectDir,
  "public",
  "badges",
);

const generatedDir = path.join(
  projectDir,
  "src",
  "generated",
);

const manifestPath = path.join(
  generatedDir,
  "badges.json",
);

fs.mkdirSync(publicDir, { recursive: true });
fs.mkdirSync(generatedDir, { recursive: true });

function cleanName(filename) {
  const lastDot = filename.lastIndexOf(".");

  if (lastDot <= 0) return filename;

  return filename.slice(0, lastDot);
}

function clearPublicBadges() {
  for (const entry of fs.readdirSync(publicDir, {
    withFileTypes: true,
  })) {
    if (entry.isFile()) {
      fs.rmSync(path.join(publicDir, entry.name));
    }
  }
}

if (!fs.existsSync(sharedDir)) {
  clearPublicBadges();
  fs.writeFileSync(manifestPath, "[]\n");

  console.log(
    `[badges] shared folder not found: ${sharedDir}`,
  );

  process.exit(0);
}

const files = fs
  .readdirSync(sharedDir, { withFileTypes: true })
  .filter(
    (entry) =>
      entry.isFile() &&
      !entry.name.startsWith("."),
  )
  .map((entry) => entry.name)
  .sort((a, b) => a.localeCompare(b));

clearPublicBadges();

const manifest = [];

for (const filename of files) {
  fs.copyFileSync(
    path.join(sharedDir, filename),
    path.join(publicDir, filename),
  );

  const name = cleanName(filename);

  manifest.push({
    name,
    url: `https://${name}`,
    file: filename,
  });
}

fs.writeFileSync(
  manifestPath,
  JSON.stringify(manifest, null, 2) + "\n",
);

console.log(
  `[badges] synced ${files.length} file(s) from ${sharedDir}`,
);

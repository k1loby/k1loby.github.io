import {
  Castle,
  ExternalLink,
  Github,
  Link as LinkIcon,
} from "lucide-react";

import { EmptyState } from "../components/empty-state";
import { socials } from "../content/socials";

function SocialIcon({
  kind,
}: {
  kind: "github" | "castle" | "website";
}) {
  if (kind === "github") return <Github />;
  if (kind === "castle") return <Castle />;
  return <LinkIcon />;
}

export default function SocialsPage() {
  return (
    <div className="page reveal">
      <header className="page-head">
        <p className="eyebrow">contact</p>
        <h1>socials</h1>
      </header>

      {socials.length ? (
        <div className="social-list">
          {socials.map((social) => (
            <a
              className="social-row"
              href={social.href}
              target="_blank"
              rel="noreferrer"
              key={social.href}
            >
              <span className="social-icon">
                <SocialIcon kind={social.kind} />
              </span>

              <span className="social-copy">
                <strong>{social.name}</strong>
                <span>{social.href}</span>
              </span>

              <ExternalLink className="social-external" />
            </a>
          ))}
        </div>
      ) : (
        <EmptyState
          title="nothing here"
          description="i forgot to add the stuff sorry"
        />
      )}
    </div>
  );
}

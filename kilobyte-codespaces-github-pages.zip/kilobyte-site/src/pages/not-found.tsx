import { Link } from "react-router-dom";

import { EmptyState } from "../components/empty-state";

export default function NotFoundPage() {
  return (
    <div className="page reveal">
      <EmptyState
        title="404"
        description="i forgot to add the stuff sorry"
      />

      <div className="center">
        <Link className="text-link" to="/">
          go home
        </Link>
      </div>
    </div>
  );
}

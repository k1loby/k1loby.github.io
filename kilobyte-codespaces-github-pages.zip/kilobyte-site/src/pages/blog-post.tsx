import React from "react";
import { ArrowLeft } from "lucide-react";
import ReactMarkdown from "react-markdown";
import { Link, useParams } from "react-router-dom";
import remarkGfm from "remark-gfm";

import { EmptyState } from "../components/empty-state";
import { getPost, resolvePublicAsset } from "../lib/blog";

function preprocessTasks(body: string) {
  return body.replace(
    /^(\s*[-*+]\s+)\[~\]\s+(.*)$/gm,
    "$1[ ] ⏳MIDWAY⏳ $2",
  );
}

function InlineProgress({ value }: { value: number }) {
  const safe = Math.max(0, Math.min(100, value));

  return (
    <div className="md-progress-block">
      <div className="md-progress-label">
        <span>progress</span>
        <strong>{safe}%</strong>
      </div>

      <div
        className="md-progress-track"
        role="progressbar"
        aria-valuemin={0}
        aria-valuemax={100}
        aria-valuenow={safe}
      >
        <div
          className="md-progress-fill"
          style={{ width: `${safe}%` }}
        />
      </div>
    </div>
  );
}

const markdownComponents = {
  li({
    children,
    className,
    ...props
  }: React.ComponentProps<"li">) {
    const childArray = React.Children.toArray(children);

    function cleanNode(node: React.ReactNode): React.ReactNode {
      if (typeof node === "string") {
        return node.replace("⏳MIDWAY⏳ ", "");
      }

      if (React.isValidElement<{ children?: React.ReactNode }>(node)) {
        const nested = React.Children.toArray(node.props.children);
        const hasMarker = nested.some(
          (child) =>
            typeof child === "string" &&
            child.includes("⏳MIDWAY⏳"),
        );

        if (hasMarker) {
          return React.cloneElement(
            node,
            undefined,
            nested.map(cleanNode),
          );
        }
      }

      return node;
    }

    function hasMarker(node: React.ReactNode): boolean {
      if (typeof node === "string") {
        return node.includes("⏳MIDWAY⏳");
      }

      if (React.isValidElement<{ children?: React.ReactNode }>(node)) {
        return React.Children.toArray(node.props.children).some(
          hasMarker,
        );
      }

      return false;
    }

    const midway = childArray.some(hasMarker);
    const cleaned = childArray.map(cleanNode);

    return (
      <li
        className={[
          className,
          midway ? "task-midway" : "",
        ]
          .filter(Boolean)
          .join(" ")}
        {...props}
      >
        {cleaned}
      </li>
    );
  },
};

function MarkdownWithProgress({ body }: { body: string }) {
  const processed = preprocessTasks(body);

  const parts = processed.split(
    /(\[\[progress:\d{1,3}\]\])/g,
  );

  return (
    <>
      {parts.map((part, index) => {
        const match = part.match(
          /^\[\[progress:(\d{1,3})\]\]$/,
        );

        if (match) {
          return (
            <InlineProgress
              key={`progress-${index}`}
              value={Number(match[1])}
            />
          );
        }

        if (!part.trim()) return null;

        return (
          <ReactMarkdown
            key={`markdown-${index}`}
            remarkPlugins={[remarkGfm]}
            components={markdownComponents}
          >
            {part}
          </ReactMarkdown>
        );
      })}
    </>
  );
}

export default function BlogPostPage() {
  const { slug } = useParams();
  const post = getPost(slug);

  if (!post) {
    return (
      <div className="page reveal">
        <EmptyState
          title="post not found"
          description="i forgot to add the stuff sorry"
        />
      </div>
    );
  }

  return (
    <article className="page article reveal">
      <Link className="back-link" to="/blog">
        <ArrowLeft /> blog
      </Link>

      {post.thumbnail ? (
        <img
          className="article-thumbnail"
          src={resolvePublicAsset(post.thumbnail)}
          alt=""
        />
      ) : null}

      <header className="article-head">
        <p className="eyebrow">{post.date}</p>
        <h1>{post.title}</h1>
        <p>{post.description}</p>

        {post.tags.length ? (
          <div className="tags">
            {post.tags.map((tag) => (
              <span key={tag}>{tag}</span>
            ))}
          </div>
        ) : null}
      </header>

      <div className="markdown">
        <MarkdownWithProgress body={post.body} />
      </div>
    </article>
  );
}

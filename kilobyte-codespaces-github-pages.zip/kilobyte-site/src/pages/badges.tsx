import { useEffect, useRef, useState } from "react";

import { EmptyState } from "../components/empty-state";
import { badges } from "../lib/badges";

function BadgeLink({
  name,
  url,
  image,
}: {
  name: string;
  url: string;
  image: string;
}) {
  const [touchTooltip, setTouchTooltip] = useState(false);
  const timer = useRef<number | null>(null);

  useEffect(() => {
    return () => {
      if (timer.current !== null) {
        window.clearTimeout(timer.current);
      }
    };
  }, []);

  function showTouchTooltip() {
    setTouchTooltip(true);

    if (timer.current !== null) {
      window.clearTimeout(timer.current);
    }

    timer.current = window.setTimeout(() => {
      setTouchTooltip(false);
      timer.current = null;
    }, 1800);
  }

  function onClick(event: React.MouseEvent<HTMLAnchorElement>) {
    const touchLike =
      window.matchMedia("(hover: none), (pointer: coarse)").matches;

    if (touchLike && !touchTooltip) {
      event.preventDefault();
      showTouchTooltip();
    }
  }

  return (
    <a
      className={[
        "badge-card",
        touchTooltip ? "is-tooltip-open" : "",
      ]
        .filter(Boolean)
        .join(" ")}
      href={url}
      target="_blank"
      rel="noreferrer"
      aria-label={`${name}: ${url}`}
      onClick={onClick}
      onBlur={() => setTouchTooltip(false)}
    >
      <img
        src={image}
        alt={`${name} badge`}
        loading="lazy"
      />

      <span className="badge-redirect-tooltip" role="tooltip">
        {url}
      </span>
    </a>
  );
}

export default function BadgesPage() {
  return (
    <div className="page reveal">
      <header className="page-head">
        <p className="eyebrow">badges / stickers</p>
        <h1>links</h1>
      </header>

      {badges.length ? (
        <div className="badge-grid">
          {badges.map((badge) => (
            <BadgeLink
              key={badge.name}
              name={badge.name}
              url={badge.url}
              image={badge.image}
            />
          ))}
        </div>
      ) : (
        <EmptyState
          title="nothing here"
          description="i forgot to add the stuff sorry"
        />
      )}
    </div>
  );
}

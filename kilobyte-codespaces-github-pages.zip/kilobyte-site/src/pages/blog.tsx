import {
  ArrowUpRight,
  Search,
} from "lucide-react";
import { useMemo, useState } from "react";
import { Link } from "react-router-dom";

import { EmptyState } from "../components/empty-state";
import { blogPosts, resolvePublicAsset } from "../lib/blog";

export default function BlogPage() {
  const [query, setQuery] = useState("");

  const posts = useMemo(() => {
    const needle = query.trim().toLowerCase();

    if (!needle) return blogPosts;

    return blogPosts.filter((post) =>
      [
        post.title,
        post.description,
        ...post.tags,
      ]
        .join(" ")
        .toLowerCase()
        .includes(needle),
    );
  }, [query]);

  return (
    <div className="page reveal">
      <header className="page-head">
        <p className="eyebrow">blog</p>
        <h1>notes</h1>
        <p>markdown files pretending to be a real blog.</p>
      </header>

      <label className="search-field">
        <Search />
        <input
          value={query}
          onChange={(event) =>
            setQuery(event.target.value)
          }
          placeholder="search posts"
          aria-label="search posts"
        />
      </label>

      {posts.length ? (
        <div className="blog-card-grid">
          {posts.map((post) => (
            <Link
              className="blog-image-card"
              to={`/blog/${post.slug}`}
              key={post.slug}
            >
              {post.thumbnail ? (
                <img
                  className="blog-card-background"
                  src={resolvePublicAsset(
                    post.thumbnail,
                  )}
                  alt=""
                  loading="lazy"
                />
              ) : null}

              <div
                className="blog-card-shade"
                aria-hidden="true"
              />

              <div className="blog-card-content">
                <div className="blog-card-top">
                  <time>{post.date}</time>

                  <ArrowUpRight
                    className="blog-card-arrow"
                    aria-hidden="true"
                  />
                </div>

                <div className="blog-card-bottom">
                  <strong>{post.title}</strong>

                  <p>{post.description}</p>

                  {typeof post.progress === "number" ? (
                    <div className="blog-card-progress">
                      <div
                        style={{
                          width: `${post.progress}%`,
                        }}
                      />
                    </div>
                  ) : null}

                  {post.tags.length ? (
                    <div className="blog-card-tags">
                      {post.tags.map((tag) => (
                        <span key={tag}>{tag}</span>
                      ))}
                    </div>
                  ) : null}
                </div>
              </div>
            </Link>
          ))}
        </div>
      ) : (
        <EmptyState
          title={
            query
              ? "no matching posts"
              : "no posts yet"
          }
          description={
            query
              ? "try another search."
              : "i forgot to add the stuff sorry"
          }
        />
      )}
    </div>
  );
}

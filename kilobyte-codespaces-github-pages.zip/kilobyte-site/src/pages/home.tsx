import { ArrowUpRight } from "lucide-react";
import { Link } from "react-router-dom";

import { Button } from "../components/core/button";
import { blogPosts, resolvePublicAsset } from "../lib/blog";
import { useProjects } from "../lib/projects";
import { site } from "../site";
import { EmptyState } from "../components/empty-state";
import { LoadingIndicator } from "../components/loading-indicator";

export default function HomePage() {
  const latest = blogPosts[0];
  const { projects, loading } = useProjects();

  return (
    <div className="page page-home">
      <section className="hero reveal">

        <p className="eyebrow">hello.</p>
        <h1>{site.tagline}</h1>
        <p className="hero-copy">{site.description}</p>

        <div className="hero-actions">
          <Button variant="primary">
            <Link to="/projects">projects</Link>
          </Button>

          <Button variant="quiet">
            <Link to="/blog">blog</Link>
          </Button>
        </div>
      </section>

      <section className="section reveal">
        <div className="section-head">
          <div>
            <p className="eyebrow">projects</p>
            <h2>some of my projects, scripts</h2>
          </div>

          <Link className="text-link" to="/projects">
            all projects <ArrowUpRight />
          </Link>
        </div>

        {loading ? (
          <LoadingIndicator />
        ) : projects.length ? (
          <div className="compact-list">
            {projects.slice(0, 3).map((project) => (
              <a
                className="list-row"
                key={project.repo}
                href={project.href}
                target="_blank"
                rel="noreferrer"
              >
                <div>
                  <strong>{project.name}</strong>
                  <p>{project.description}</p>
                </div>

                {project.tags.length ? (
                  <span className="muted">
                    {project.tags.join(" / ")}
                  </span>
                ) : null}
              </a>
            ))}
          </div>
        ) : (
          <EmptyState
            title="nothing here yet"
            description="i forgot to add the stuff sorry"
          />
        )}
      </section>

      <section className="section reveal">
        <div className="section-head">
          <div>
            <p className="eyebrow">blog</p>
            <h2>latest note</h2>
          </div>
        </div>

        {latest ? (
          <Link
            className="post-preview post-preview-with-thumb"
            to={`/blog/${latest.slug}`}
          >
            {latest.thumbnail ? (
              <img
                className="post-thumbnail"
                src={resolvePublicAsset(latest.thumbnail)}
                alt=""
                loading="lazy"
              />
            ) : null}

            <div className="post-row-copy">
              <strong>{latest.title}</strong>
              <p>{latest.description}</p>
            </div>

            <time>{latest.date}</time>
          </Link>
        ) : (
          <EmptyState
            title="no posts yet"
            description="add a markdown file to src/content/blog."
          />
        )}
      </section>
    </div>
  );
}

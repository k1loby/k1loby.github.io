import {
  ExternalLink,
  ScrollText,
  Star,
} from "lucide-react";

import { EmptyState } from "../components/empty-state";
import { LoadingIndicator } from "../components/loading-indicator";
import { useProjects } from "../lib/projects";

export default function ProjectsPage() {
  const { projects, loading, error } = useProjects();

  return (
    <div className="page reveal">
      <header className="page-head">
        <p className="eyebrow">projects</p>
        <h1>some of my projects, scripts</h1>
      </header>

      {loading ? (
        <LoadingIndicator />
      ) : error ? (
        <EmptyState
          title="github did not load"
          description={error}
        />
      ) : projects.length ? (
        <div className="project-grid project-image-grid">
          {projects.map((project) => (
            <article
              className="project-card project-image-card"
              key={project.repo}
            >
              {project.thumbnail ? (
                <img
                  className="project-card-background"
                  src={project.thumbnail}
                  alt=""
                  loading="lazy"
                />
              ) : null}

              <div
                className="project-card-shade"
                aria-hidden="true"
              />

              <div className="project-card-content">
                <div className="project-card-top">
                  <strong className="project-card-name">
                    {project.name}
                  </strong>

                  <div className="project-card-meta">
                    {typeof project.stars === "number" ? (
                      <span>
                        <Star />
                        {project.stars}
                      </span>
                    ) : null}

                    {project.language ? (
                      <span>{project.language}</span>
                    ) : null}

                    {project.license ? (
                      <span>
                        <ScrollText />
                        {project.license}
                      </span>
                    ) : null}
                  </div>
                </div>

                <div className="project-card-bottom">
                  <p>{project.description}</p>

                  {project.tags.length ? (
                    <div className="project-card-tags">
                      {project.tags.map((tag) => (
                        <span key={tag}>{tag}</span>
                      ))}
                    </div>
                  ) : null}

                  <a
                    className="project-open-button"
                    href={project.href}
                    target="_blank"
                    rel="noreferrer"
                  >
                    <span>open repository</span>
                    <ExternalLink />
                  </a>
                </div>
              </div>
            </article>
          ))}
        </div>
      ) : (
        <EmptyState
          title="no projects"
          description="i forgot to add the stuff sorry"
        />
      )}
    </div>
  );
}

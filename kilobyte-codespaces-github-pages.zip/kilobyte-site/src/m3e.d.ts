import type React from "react";

declare global {
  namespace JSX {
    interface IntrinsicElements {
      "m3e-loading-indicator": React.DetailedHTMLProps<
        React.HTMLAttributes<HTMLElement> & {
          variant?: "contained" | "standard";
        },
        HTMLElement
      >;
    }
  }
}

export {};

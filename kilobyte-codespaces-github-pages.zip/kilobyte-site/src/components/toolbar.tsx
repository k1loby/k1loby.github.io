import {
  BookOpenText,
  FolderKanban,
  Home,
  AtSign,
  Moon,
  Pencil,
  Sticker,
  Sun,
} from "lucide-react";
import { NavLink } from "react-router-dom";

import { Button } from "./core/button";
import { Tooltip, TooltipContent } from "./core/tooltip";

function Tool({
  label,
  children,
}: {
  label: string;
  children: React.ReactElement;
}) {
  return (
    <Tooltip>
      {children}
      <TooltipContent placement="bottom" className="toolbar-tooltip">{label}</TooltipContent>
    </Tooltip>
  );
}

const drawHref = `${import.meta.env.BASE_URL}draw/`;

export function Toolbar({
  dark,
  onTheme,
}: {
  dark: boolean;
  onTheme: () => void;
}) {
  return (
    <nav className="toolbar-shell" aria-label="main navigation">
      <div className="toolbar">
        <Tool label="home">
          <NavLink
            to="/"
            className={({ isActive }) =>
              `toolbar-link ${isActive ? "is-active" : ""}`
            }
            aria-label="home"
          >
            <Home />
          </NavLink>
        </Tool>

        <Tool label="projects">
          <NavLink
            to="/projects"
            className={({ isActive }) =>
              `toolbar-link ${isActive ? "is-active" : ""}`
            }
            aria-label="projects"
          >
            <FolderKanban />
          </NavLink>
        </Tool>

        <Tool label="blog">
          <NavLink
            to="/blog"
            className={({ isActive }) =>
              `toolbar-link ${isActive ? "is-active" : ""}`
            }
            aria-label="blog"
          >
            <BookOpenText />
          </NavLink>
        </Tool>

        <Tool label="badges / stickers">
          <NavLink
            to="/badges"
            className={({ isActive }) =>
              `toolbar-link ${isActive ? "is-active" : ""}`
            }
            aria-label="badges / stickers"
          >
            <Sticker />
          </NavLink>
        </Tool>

        <Tool label="socials">
          <NavLink
            to="/socials"
            className={({ isActive }) =>
              `toolbar-link ${isActive ? "is-active" : ""}`
            }
            aria-label="socials"
          >
            <AtSign />
          </NavLink>
        </Tool>


        <Tool label="Whiteboard for sketching around">
          <a
            className="toolbar-link"
            href={drawHref}
            aria-label="Whiteboard for sketching around"
          >
            <Pencil />
          </a>
        </Tool>

        <Tool label={dark ? "light mode" : "dark mode"}>
          <Button
            variant="quiet"
            isIconOnly
            aria-label={dark ? "light mode" : "dark mode"}
            onPress={onTheme}
            className="toolbar-theme"
          >
            {dark ? <Sun /> : <Moon />}
          </Button>
        </Tool>
      </div>
    </nav>
  );
}

import type {
  CSSProperties,
  HTMLAttributes,
  ReactNode,
} from "react";

import { cn } from "../../lib/cn";

export interface TooltipProps {
  children: ReactNode;
  delay?: number;
  closeDelay?: number;
}

export function Tooltip({
  children,
}: TooltipProps) {
  return (
    <span className="m3e-tooltip-root">
      {children}
    </span>
  );
}

export interface TooltipContentProps
  extends HTMLAttributes<HTMLSpanElement> {
  placement?: "top" | "bottom" | "left" | "right";
  offset?: number;
  hideArrow?: boolean;
}

export function TooltipContent({
  placement = "bottom",
  offset = 8,
  hideArrow = false,
  children,
  className,
  style,
  ...props
}: TooltipContentProps) {
  const tooltipStyle = {
    ...style,
    "--m3e-tooltip-offset": `${offset}px`,
  } as CSSProperties;

  return (
    <span
      role="tooltip"
      data-placement={placement}
      className={cn("m3e-tooltip", className)}
      style={tooltipStyle}
      {...props}
    >
      {children}

      {!hideArrow ? (
        <span
          className="m3e-tooltip-arrow"
          aria-hidden="true"
        />
      ) : null}
    </span>
  );
}

import type {
  ButtonHTMLAttributes,
  MouseEventHandler,
} from "react";

import { cn } from "../../lib/cn";

type ButtonVariant =
  | "primary"
  | "secondary"
  | "quiet"
  | "danger"
  | "warning";

type ButtonSize = "sm" | "md" | "lg";

export interface ButtonProps
  extends Omit<ButtonHTMLAttributes<HTMLButtonElement>, "onClick"> {
  variant?: ButtonVariant;
  size?: ButtonSize;
  isIconOnly?: boolean;
  onPress?: () => void;
  onClick?: MouseEventHandler<HTMLButtonElement>;
}

export function Button({
  variant = "secondary",
  size = "md",
  isIconOnly = false,
  className,
  onPress,
  onClick,
  type = "button",
  ...props
}: ButtonProps) {
  const handleClick: MouseEventHandler<HTMLButtonElement> = (event) => {
    onClick?.(event);

    if (!event.defaultPrevented) {
      onPress?.();
    }
  };

  return (
    <button
      type={type}
      data-button=""
      data-icon-only={isIconOnly ? "" : undefined}
      className={cn(
        "m3e-button",
        `m3e-button-${variant}`,
        `m3e-button-${size}`,
        isIconOnly && "m3e-button-icon",
        className,
      )}
      onClick={handleClick}
      {...props}
    />
  );
}

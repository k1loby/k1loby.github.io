export function KilobyteLogo({
  className = "",
}: {
  className?: string;
}) {
  return (
    <svg
      className={`kilobyte-logo ${className}`.trim()}
      viewBox="0 0 256 256"
      role="img"
      aria-label="kilobyte"
    >
      <defs>
        <linearGradient
          id="kb-mint"
          x1="54"
          y1="36"
          x2="208"
          y2="220"
          gradientUnits="userSpaceOnUse"
        >
          <stop offset="0" stopColor="#7cf1d3" />
          <stop offset="0.52" stopColor="#48ddb8" />
          <stop offset="1" stopColor="#18bd95" />
        </linearGradient>

        <linearGradient
          id="kb-glass"
          x1="35"
          y1="72"
          x2="176"
          y2="201"
          gradientUnits="userSpaceOnUse"
        >
          <stop offset="0" stopColor="#ffffff" stopOpacity="0.72" />
          <stop offset="0.34" stopColor="#f5fffc" stopOpacity="0.48" />
          <stop offset="0.68" stopColor="#a8f4df" stopOpacity="0.26" />
          <stop offset="1" stopColor="#75e2c7" stopOpacity="0.12" />
        </linearGradient>

        <linearGradient
          id="kb-glass-edge"
          x1="41"
          y1="69"
          x2="155"
          y2="205"
          gradientUnits="userSpaceOnUse"
        >
          <stop offset="0" stopColor="#ffffff" stopOpacity="0.82" />
          <stop offset="0.55" stopColor="#ffffff" stopOpacity="0.34" />
          <stop offset="1" stopColor="#ffffff" stopOpacity="0.16" />
        </linearGradient>

        <filter
          id="kb-letter-shadow"
          x="18"
          y="12"
          width="230"
          height="236"
          filterUnits="userSpaceOnUse"
        >
          <feDropShadow
            dx="0"
            dy="8"
            stdDeviation="8"
            floodColor="#0b5b4a"
            floodOpacity="0.22"
          />
        </filter>

        <filter
          id="kb-glass-shadow"
          x="8"
          y="48"
          width="210"
          height="198"
          filterUnits="userSpaceOnUse"
        >
          <feDropShadow
            dx="0"
            dy="5"
            stdDeviation="5"
            floodColor="#07110e"
            floodOpacity="0.18"
          />
        </filter>
      </defs>

      <g filter="url(#kb-letter-shadow)">
        <text
          x="35"
          y="209"
          className="kilobyte-logo-letter"
          fill="url(#kb-mint)"
          stroke="#52dfbd"
          strokeWidth="7"
          strokeLinejoin="round"
          strokeLinecap="round"
          paintOrder="stroke fill"
        >
          K
        </text>
      </g>

      <g filter="url(#kb-glass-shadow)">
        <path
          className="kilobyte-logo-glass"
          d="
            M 26 88
            Q 20 72 39 72
            H 166
            Q 184 72 175 88
            L 116 196
            Q 106 215 96 196
            Z
          "
          fill="url(#kb-glass)"
          stroke="url(#kb-glass-edge)"
          strokeWidth="2.4"
          strokeLinejoin="round"
        />

        <path
          d="M 42 79 H 158"
          stroke="#ffffff"
          strokeOpacity="0.34"
          strokeWidth="3"
          strokeLinecap="round"
        />

        <path
          d="M 49 84 L 103 184"
          stroke="#ffffff"
          strokeOpacity="0.09"
          strokeWidth="14"
          strokeLinecap="round"
        />
      </g>
    </svg>
  );
}

import { createElement } from "react";

export function LoadingIndicator() {
  return createElement(
    "m3e-loading-indicator" as any,
    {
      variant: "contained",
      "aria-label": "loading",
    },
  );
}

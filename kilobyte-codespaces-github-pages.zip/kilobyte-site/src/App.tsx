import { Info } from "lucide-react";
import { useEffect, useState } from "react";
import { Route, Routes } from "react-router-dom";

import { Toolbar } from "./components/toolbar";
import BadgesPage from "./pages/badges";
import BlogPage from "./pages/blog";
import BlogPostPage from "./pages/blog-post";
import HomePage from "./pages/home";
import NotFoundPage from "./pages/not-found";
import ProjectsPage from "./pages/projects";
import SocialsPage from "./pages/socials";
import { site } from "./site";

function initialDark() {
  const saved = localStorage.getItem("theme");

  if (saved === "dark") return true;
  if (saved === "light") return false;

  return matchMedia("(prefers-color-scheme: dark)").matches;
}

export default function App() {
  const [dark, setDark] = useState(initialDark);

  useEffect(() => {
    document.documentElement.classList.toggle("dark", dark);
    document.documentElement.style.colorScheme = dark ? "dark" : "light";
    localStorage.setItem("theme", dark ? "dark" : "light");
  }, [dark]);

  useEffect(() => {
    document.title = site.name;
  }, []);

  return (
    <>
      <div className="site-notice" role="status">
        <Info aria-hidden="true" />
        <span>
          the website isnt finished yet lads but you can still look and view
        </span>
      </div>

      <Toolbar dark={dark} onTheme={() => setDark((value) => !value)} />

      <main className="site-shell">
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/projects" element={<ProjectsPage />} />
          <Route path="/blog" element={<BlogPage />} />
          <Route path="/blog/:slug" element={<BlogPostPage />} />
          <Route path="/badges" element={<BadgesPage />} />
          <Route path="/socials" element={<SocialsPage />} />
          <Route path="*" element={<NotFoundPage />} />
        </Routes>
      </main>
    </>
  );
}

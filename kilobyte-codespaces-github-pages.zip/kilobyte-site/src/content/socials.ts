export type Social = {
  name: string;
  href: string;
  kind: "github" | "castle" | "website";
};

export const socials: Social[] = [
  {
    name: "github",
    href: "https://github.com/Bongoer",
    kind: "github",
  },
  {
    name: "castle",
    href: "https://castle.xyz/@kilobyte",
    kind: "castle",
  },
];

---
title: "markdown stress test"
date: "2026-09-20"
description: "testing all the current markdown sizes and components"
tags: [markdown, test, ipsum]
thumbnail: "blog/markdown-stress-test.svg"
---

# Heading 1

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer feugiat, justo at blandit placerat, mauris arcu consequat neque, vel feugiat sapien ipsum id lorem.

## Heading 2

Sed posuere consectetur est at lobortis. Donec ullamcorper nulla non metus auctor fringilla. Curabitur blandit tempus porttitor.

### Heading 3

Maecenas faucibus mollis interdum. Vestibulum id ligula porta felis euismod semper.

#### Heading 4

Aenean lacinia bibendum nulla sed consectetur. Praesent commodo cursus magna, vel scelerisque nisl consectetur et.

##### Heading 5

Nullam quis risus eget urna mollis ornare vel eu leo.

###### Heading 6

Cras mattis consectetur purus sit amet fermentum.

---

## Text styles

Normal text.

**Bold text**

*Italic text*

***Bold and italic text***

~~Strikethrough text~~

`inline code`

[GitHub](https://github.com/Bongoer)

A longer paragraph for line-height and wrapping:

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor. Etiam porta sem malesuada magna mollis euismod. Nullam id dolor id nibh ultricies vehicula ut id elit. Morbi leo risus, porta ac consectetur ac, vestibulum at eros.

---

## Blockquote

> Lorem ipsum dolor sit amet, consectetur adipiscing elit.
>
> This is a second paragraph inside the quote.
>
> **Bold inside a quote** and `inline code`.

---

## Unordered list

- Alpha
- Beta
- Gamma
  - Nested item
  - Another nested item
    - Third level
- Delta

## Ordered list

1. First item
2. Second item
3. Third item
   1. Nested first
   2. Nested second
4. Fourth item

---

## Checklist

- [x] finished item
- [~] midway item
- [ ] unfinished item
- [x] another finished item
- [ ] another unfinished item

---

## Progress

[[progress:0]]

[[progress:25]]

[[progress:50]]

[[progress:75]]

[[progress:100]]

---

## Table

| Component | Status | Notes |
| --- | --- | --- |
| Headings | Working | H1 through H6 |
| Lists | Working | Nested too |
| Checklist | Testing | checked / midway / empty |
| Progress | Testing | custom syntax |
| Tables | Working | GFM table |

---

## Code block

```js
function hello(name) {
  return `hello ${name}`;
}

console.log(hello("world"));
```

```css
.example {
  display: grid;
  gap: 1rem;
  border-radius: 24px;
}
```

---

## Mixed content

### Small section with everything

Lorem ipsum dolor sit amet, **bold consectetur**, *italic adipiscing*, and `inlineCode()`.

> A short quote below a heading.

- [x] typography
- [~] spacing
- [ ] final polish

[[progress:67]]

1. one
2. two
3. three

---

## Very long line wrapping

Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.

## End

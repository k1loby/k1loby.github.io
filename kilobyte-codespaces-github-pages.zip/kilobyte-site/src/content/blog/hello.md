---
title: "hello markdown"
date: "2026-09-19"
description: "i forgot to add the stuff sorry"
tags: [site, notes]
thumbnail: "blog/hello.svg"
---

# hello

i forgot to add the stuff sorry

- [x] website
- [~] blog
- [ ] projects

[[progress:50]]

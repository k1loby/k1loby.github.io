import type {
  HTMLAttributes,
} from "react";

declare module "react" {
  namespace JSX {
    interface IntrinsicElements {
      "m3e-loading-indicator":
        HTMLAttributes<HTMLElement> & {
          variant?: "contained" | "standard";
        };
    }
  }
}

export {};

Put badge/sticker images in:

/sdcard/Download/dotui-badges/

Supported:
.gif
.png
.jpg
.jpeg
.webp
.svg
.avif

Examples:

castle.xyz.png  -> https://castle.xyz
vuvien.xyz.webp -> https://vuvien.xyz

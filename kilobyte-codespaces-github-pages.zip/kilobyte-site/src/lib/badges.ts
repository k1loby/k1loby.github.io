import manifest from "../generated/badges.json";

export type Badge = {
  name: string;
  url: string;
  image: string;
};

type BadgeManifestItem = {
  name: string;
  url: string;
  file: string;
};

export const badges: Badge[] = (
  manifest as BadgeManifestItem[]
).map((item) => ({
  name: item.name,
  url: item.url,
  image:
    `${import.meta.env.BASE_URL}badges/` +
    encodeURIComponent(item.file),
}));

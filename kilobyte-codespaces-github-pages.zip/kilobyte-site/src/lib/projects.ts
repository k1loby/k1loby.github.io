import { useEffect, useState } from "react";

import {
  loadProjects,
  type Project,
} from "../content/projects";

export function useProjects() {
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;

    setLoading(true);
    setError(null);

    loadProjects()
      .then((items) => {
        if (cancelled) return;
        setProjects(items);
      })
      .catch((reason: unknown) => {
        if (cancelled) return;

        const message =
          reason instanceof Error
            ? reason.message
            : "could not load github repositories";

        setProjects([]);
        setError(message);
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });

    return () => {
      cancelled = true;
    };
  }, []);

  return { projects, loading, error };
}

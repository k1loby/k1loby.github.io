export type BlogPost = {
  slug: string;
  title: string;
  date: string;
  description: string;
  tags: string[];
  thumbnail?: string;
  progress?: number;
  body: string;
};

const markdownModules = import.meta.glob<string>(
  "../content/blog/*.md",
  {
    query: "?raw",
    import: "default",
    eager: true,
  },
);

function unquote(value: string) {
  return value.replace(/^["']|["']$/g, "").trim();
}

function parseFrontmatter(raw: string) {
  if (!raw.startsWith("---\n")) {
    return { attributes: {} as Record<string, string>, body: raw };
  }

  const end = raw.indexOf("\n---", 4);
  if (end === -1) {
    return { attributes: {} as Record<string, string>, body: raw };
  }

  const block = raw.slice(4, end).trim();
  const body = raw.slice(end + 4).trim();
  const attributes: Record<string, string> = {};

  for (const line of block.split("\n")) {
    const separator = line.indexOf(":");
    if (separator === -1) continue;

    const key = line.slice(0, separator).trim();
    const value = line.slice(separator + 1).trim();

    attributes[key] = unquote(value);
  }

  return { attributes, body };
}

function slugFromPath(path: string) {
  return path.split("/").pop()!.replace(/\.md$/, "");
}

export const blogPosts: BlogPost[] = Object.entries(markdownModules)
  .map(([path, raw]) => {
    const { attributes, body } = parseFrontmatter(raw);

    return {
      slug: slugFromPath(path),
      title: attributes.title || slugFromPath(path),
      date: attributes.date || "",
      description: attributes.description || "",
      tags: (attributes.tags || "")
        .replace(/^\[|\]$/g, "")
        .split(",")
        .map((tag) => unquote(tag))
        .filter(Boolean),
      thumbnail: attributes.thumbnail || undefined,
      progress: attributes.progress
        ? Math.max(0, Math.min(100, Number(attributes.progress)))
        : undefined,
      body,
    };
  })
  .sort((a, b) => b.date.localeCompare(a.date));

export function getPost(slug?: string) {
  return blogPosts.find((post) => post.slug === slug);
}


export function resolvePublicAsset(path?: string) {
  if (!path) return undefined;

  const cleaned = path.replace(/^\/+/, "");
  return `${import.meta.env.BASE_URL}${cleaned}`;
}
